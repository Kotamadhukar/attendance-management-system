import 'package:flutter/material.dart';

class AttendanceManagementPage extends StatefulWidget {
  @override
  _AttendanceManagementPageState createState() => _AttendanceManagementPageState();
}

class _AttendanceManagementPageState extends State<AttendanceManagementPage> {
  final Map<String, Map<String, List<Student>>> classSectionData = {
    'Class 1': {
      'Section A': [
        Student(name: 'Kota Madhukar', isPresent: null),
        Student(name: 'Tony Stark', isPresent: null),
      ],
      'Section B': [
        Student(name: 'Mukeshwar Reddy', isPresent: null),
        Student(name: 'amreen', isPresent: null),
        Student(name: 'nagarjuna', isPresent: null),
        Student(name: 'shiridi', isPresent: null),
      ],
    },
    'Class 2': {
      'Section A': [
        Student(name: 'raju', isPresent: null),
        Student(name: 'prashanth neel', isPresent: null),
        Student(name: 'kamal', isPresent: null),
        Student(name: 'thala dhoni', isPresent: null),
      ],
      'Section B': [
        Student(name: 'james rhodes', isPresent: null),
        Student(name: 'sathish', isPresent: null),
        Student(name: 'peter parker', isPresent: null),
      ],
    },
  };

  String? selectedClass;
  String? selectedSection;
  List<Student> students = [];

  @override
  void initState() {
    super.initState();
    if (classSectionData.isNotEmpty) {
      selectedClass = classSectionData.keys.first;
      selectedSection = classSectionData[selectedClass!]!.keys.first;
      students = classSectionData[selectedClass!]![selectedSection!]!;
    }
  }

  void updateStudents() {
    if (selectedClass != null && selectedSection != null) {
      setState(() {
        students = classSectionData[selectedClass!]![selectedSection!]!;
      });
    }
  }

  void markAttendance(int index, bool isPresent) {
    setState(() {
      students[index].isPresent = isPresent;
    });
  }

  void submitAttendance() {
    // Show a success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Submitted successfully')),
    );

    // Store the attendance data globally or pass it to the overview page
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Management'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.blue, width: 1.0),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: DropdownButton<String>(
                      value: selectedClass,
                      onChanged: (value) {
                        setState(() {
                          selectedClass = value;
                          selectedSection = classSectionData[selectedClass!]!.keys.first;
                          updateStudents();
                        });
                      },
                      items: classSectionData.keys.map<DropdownMenuItem<String>>((String key) {
                        return DropdownMenuItem<String>(
                          value: key,
                          child: Text(key),
                        );
                      }).toList(),
                      underline: SizedBox(),
                      isExpanded: true,
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.blue, width: 1.0),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: DropdownButton<String>(
                      value: selectedSection,
                      onChanged: (value) {
                        setState(() {
                          selectedSection = value;
                          updateStudents();
                        });
                      },
                      items: selectedClass != null
                          ? classSectionData[selectedClass!]!.keys.map<DropdownMenuItem<String>>((String key) {
                        return DropdownMenuItem<String>(
                          value: key,
                          child: Text(key),
                        );
                      }).toList()
                          : [],
                      underline: SizedBox(),
                      isExpanded: true,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.blue, width: 1.0),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: ListView.builder(
                itemCount: students.length,
                itemBuilder: (context, index) {
                  return Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                    child: ListTile(
                      title: Text(students[index].name),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.check_circle,
                              color: students[index].isPresent == true ? Colors.green : Colors.grey,
                            ),
                            onPressed: () => markAttendance(index, true),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.cancel,
                              color: students[index].isPresent == false ? Colors.red : Colors.grey,
                            ),
                            onPressed: () => markAttendance(index, false),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: submitAttendance,
              style: ElevatedButton.styleFrom(
                // primary: Colors.green,
                padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 20.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              child: Text(
                'Submit',
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Student {
  String name;
  bool? isPresent;

  Student({required this.name, this.isPresent});
}
