import 'package:flutter/material.dart';
import 'super_admin_login_page.dart';
import 'sub_admin_login_page.dart';
import 'student_login_page.dart';
import 'super_admin_dashboard.dart';
import 'sub_admin_dashboard.dart';
import 'student_dashboard.dart';
import 'role_manager.dart';
import 'overview_page.dart';
import 'manage_users_page.dart';
import 'reports_page.dart';
import 'settings_page.dart';
import 'student.dart';  // Add this import

import 'subadmin_overview_page.dart' as subadmin;
import 'subadmin_manage_students_page.dart' as subadmin;
import 'subadmin_reports_page.dart' as subadmin;
import 'attendance_management_page.dart' as subadmin;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Management System',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginSelectionPage(),
        '/super_admin_login': (context) => SuperAdminLoginPage(),
        '/sub_admin_login': (context) => SubAdminLoginPage(),
        '/student_login': (context) => StudentLoginPage(),
        '/super_admin_dashboard': (context) => SuperAdminDashboard(),
        '/sub_admin_dashboard': (context) => SubAdminDashboard(),
        '/student_dashboard': (context) => StudentDashboard(),
        '/overview': (context) => OverviewPage(),
        '/manage_users': (context) => ManageUsersPage(),
        '/reports': (context) => ReportsPage(),
        '/settings': (context) => SettingsPage(),
        '/subadmin_overview': (context) => subadmin.SubadminOverviewPage(
            attendanceData: ModalRoute.of(context)!.settings.arguments
            as Map<String, Map<String, List<Student>>>),
        '/subadmin_manage_users': (context) => subadmin.SubadminManagestudentsPage(),
        '/subadmin_reports': (context) => subadmin.SubadminReportsPage(),
        '/attendance_management_page': (context) => subadmin.AttendanceManagementPage(),
      },
    );
  }
}

class LoginSelectionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Login Role'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade200, Colors.blue.shade900],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(context, '/super_admin_login');
                    },
                    icon: Icon(Icons.admin_panel_settings),
                    label: Text('Super Admin Login'),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(context, '/sub_admin_login');
                    },
                    icon: Icon(Icons.admin_panel_settings_outlined),
                    label: Text('Sub Admin Login'),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(context, '/student_login');
                    },
                    icon: Icon(Icons.school),
                    label: Text('Student Login'),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      textStyle: TextStyle(fontSize: 18),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
