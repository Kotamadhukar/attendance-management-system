import 'package:flutter/material.dart';

class OverviewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Overview'),
        backgroundColor: Colors.blueAccent, // Themed AppBar color
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildStatCard(
              title: 'Total Registered Students',
              value: '1200',
              color: Colors.blueAccent,
            ),
            SizedBox(height: 10),
            _buildStatCard(
              title: 'Total Number of Classes',
              value: '35',
              color: Colors.green,
            ),
            SizedBox(height: 10),
            _buildStatCard(
              title: 'Overall Attendance Rate',
              value: '95%',
              color: Colors.orange,
            ),
            SizedBox(height: 10),
            _buildStatCard(
              title: 'Average Attendance per Class',
              value: '98%',
              color: Colors.purple,
            ),
            SizedBox(height: 10),
            _buildStatCard(
              title: 'Total Teachers',
              value: '50',
              color: Colors.red,
            ),
            SizedBox(height: 10),
            _buildStatCard(
              title: 'Upcoming Events',
              value: 'Parent-Teacher Meeting on 25th July',
              color: Colors.teal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({required String title, required String value, required Color color}) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        tileColor: color.withOpacity(0.1), // Light background for each card
        leading: CircleAvatar(
          backgroundColor: color,
          child: Icon(
            Icons.info,
            color: Colors.white,
          ),
        ),
        title: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        subtitle: Text(value, style: TextStyle(fontSize: 16)),
      ),
    );
  }
}
