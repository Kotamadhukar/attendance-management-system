import 'package:flutter/material.dart';

class ReportsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reports'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ReportTile(
            title: 'Daily Attendance Report',
            onTap: () {
              // Navigate to Daily Attendance Report page
            },
          ),
          ReportTile(
            title: 'Monthly Attendance Report',
            onTap: () {
              // Navigate to Monthly Attendance Report page
            },
          ),
          ReportTile(
            title: 'Individual Student Attendance Report',
            onTap: () {
              // Navigate to Individual Student Attendance Report page
            },
          ),
          ReportTile(
            title: 'Class-wise Attendance Report',
            onTap: () {
              // Navigate to Class-wise Attendance Report page
            },
          ),
          ReportTile(
            title: 'Attendance Performance Analysis',
            onTap: () {
              // Navigate to Attendance Performance Analysis page
            },
          ),
          ReportTile(
            title: 'Top Attendees',
            onTap: () {
              // Navigate to Top Attendees page
            },
          ),
          ReportTile(
            title: 'Low Attendance Alert',
            onTap: () {
              // Navigate to Low Attendance Alert page
            },
          ),
          ReportTile(
            title: 'Yearly Attendance Trends',
            onTap: () {
              // Navigate to Yearly Attendance Trends page
            },
          ),
          ReportTile(
            title: 'Seasonal Attendance Patterns',
            onTap: () {
              // Navigate to Seasonal Attendance Patterns page
            },
          ),
          ReportTile(
            title: 'Custom Date Range Reports',
            onTap: () {
              // Navigate to Custom Date Range Reports page
            },
          ),
          ReportTile(
            title: 'Filtered Reports',
            onTap: () {
              // Navigate to Filtered Reports page
            },
          ),
          ReportTile(
            title: 'Overall Attendance Summary',
            onTap: () {
              // Navigate to Overall Attendance Summary page
            },
          ),
          ReportTile(
            title: 'Teacher Attendance Reports',
            onTap: () {
              // Navigate to Teacher Attendance Reports page
            },
          ),
          ReportTile(
            title: 'Comparative Attendance Report',
            onTap: () {
              // Navigate to Comparative Attendance Report page
            },
          ),
        ],
      ),
    );
  }
}

class ReportTile extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  ReportTile({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: Colors.grey),
      ),
      elevation: 5,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        trailing: Icon(Icons.arrow_forward),
        onTap: onTap,
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ReportsPage(),
  ));
}
