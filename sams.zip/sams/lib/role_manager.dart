class RoleManager {
  static String authenticateSuperAdmin(String email, String password) {
    if (email == 'super@email.com' && password == 'password') {
      return 'success';
    } else {
      return 'Incorrect email or password';
    }
  }

  static String authenticateSubAdmin(String email, String password) {
    if (email == 'admin@email.com' && password == 'password') {
      return 'success';
    } else {
      return 'Incorrect email or password';
    }
  }

  static String authenticateStudent(String email, String password) {
    if (email == 'student@email.com' && password == 'password') {
      return 'success';
    } else {
      return 'Incorrect email or password';
    }
  }

  static String login(String role, String email, String password) {
    switch (role) {
      case 'SuperAdmin':
        return authenticateSuperAdmin(email, password);
      case 'SubAdmin':
        return authenticateSubAdmin(email, password);
      case 'Student':
        return authenticateStudent(email, password);
      default:
        return 'Invalid role';
    }
  }
}
