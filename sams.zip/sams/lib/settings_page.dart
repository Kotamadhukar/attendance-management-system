import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings', style: Theme.of(context).textTheme.headlineSmall),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('System Settings Configuration', style: Theme.of(context).textTheme.bodyLarge),
            SizedBox(height: 10),
            Text('Notification Settings', style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}
