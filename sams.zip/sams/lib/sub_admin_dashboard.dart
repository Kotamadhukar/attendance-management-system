import 'package:flutter/material.dart';
import 'student.dart';

class SubAdminDashboard extends StatelessWidget {
  final List<_DashboardItem> items = [
    _DashboardItem(Icons.dashboard, 'Overview', '/subadmin_overview'),
    _DashboardItem(Icons.person, 'Student Management', '/subadmin_manage_students_page'),
    _DashboardItem(Icons.check_circle, 'Attendance Management', '/attendance_management_page'),
    _DashboardItem(Icons.report, 'Reports', '/subadmin_reports'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sub Admin Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              _showLogoutConfirmationDialog(context);
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: EdgeInsets.all(16.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16.0,
          mainAxisSpacing: 16.0,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return _DashboardGridItem(
            icon: items[index].icon,
            title: items[index].title,
            route: items[index].route,
          );
        },
      ),
    );
  }

  void _showLogoutConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Logout'),
          content: Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                Navigator.pushReplacementNamed(context, '/login'); // Navigate to login page
              },
              child: Text('Logout'),
            ),
          ],
        );
      },
    );
  }
}

class _DashboardGridItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String route;

  const _DashboardGridItem({
    required this.icon,
    required this.title,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.blue.shade100,
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50.0, color: Colors.blue),
            SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
                color: Colors.blue.shade900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardItem {
  final IconData icon;
  final String title;
  final String route;

  _DashboardItem(this.icon, this.title, this.route);
}
