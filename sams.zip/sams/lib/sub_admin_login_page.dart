import 'package:flutter/material.dart';
import 'role_manager.dart';

class SubAdminLoginPage extends StatefulWidget {
  @override
  _SubAdminLoginPageState createState() => _SubAdminLoginPageState();
}

class _SubAdminLoginPageState extends State<SubAdminLoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _message = '';

  void _login() {
    final email = _emailController.text;
    final password = _passwordController.text;
    final result = RoleManager.login('SubAdmin', email, password);

    setState(() {
      _message = result == 'success' ? 'Login successful' : result;
    });

    if (result == 'success') {
      Navigator.pushReplacementNamed(context, '/sub_admin_dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sub Admin Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
            SizedBox(height: 20),
            Text(
              _message,
              style: TextStyle(color: Colors.red),
            ),
          ],
        ),
      ),
    );
  }
}
