import 'package:flutter/material.dart';
import 'student.dart';  // Import Student class

class SubadminOverviewPage extends StatelessWidget {
  final Map<String, Map<String, List<Student>>> attendanceData;

  SubadminOverviewPage({required this.attendanceData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Subadmin Overview'),
      ),
      body: ListView.builder(
        itemCount: attendanceData.keys.length,
        itemBuilder: (context, classIndex) {
          String className = attendanceData.keys.elementAt(classIndex);
          return ExpansionTile(
            title: Text(className),
            children: attendanceData[className]!.keys.map((sectionName) {
              return ListTile(
                title: Text(sectionName),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: attendanceData[className]![sectionName]!.map((student) {
                    return Text('${student.name}: ${student.isPresent == true ? "Present" : student.isPresent == false ? "Absent" : "Not Marked"}');
                  }).toList(),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
