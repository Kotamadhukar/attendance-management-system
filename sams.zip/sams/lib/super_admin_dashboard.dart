import 'package:flutter/material.dart';
import 'overview_page.dart';
import 'manage_users_page.dart';
import 'reports_page.dart';
import 'settings_page.dart';
//import 'login_page.dart';

class SuperAdminDashboard extends StatefulWidget {
  @override
  _SuperAdminDashboardState createState() => _SuperAdminDashboardState();
}

class _SuperAdminDashboardState extends State<SuperAdminDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Super Admin Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              _showLogoutDialog(context);
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade200, Colors.blue.shade900],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: GridView.count(
          crossAxisCount: 2,
          padding: EdgeInsets.all(10),
          children: [
            itemDashboard(context, 'Overview', Icons.dashboard, Colors.blue, '/overview'),
            itemDashboard(context, 'Manage Users', Icons.people, Colors.green, '/manage_users'),
            itemDashboard(context, 'Reports', Icons.bar_chart, Colors.red, '/reports'),
            itemDashboard(context, 'Settings', Icons.settings, Colors.orange, '/settings'),
          ],
        ),
      ),
    );
  }

  GestureDetector itemDashboard(BuildContext context, String title, IconData iconData, Color background, String route) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 5),
              color: Theme.of(context).primaryColor.withOpacity(0.2),
              spreadRadius: 2,
              blurRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: background,
                shape: BoxShape.circle,
              ),
              child: Icon(iconData, color: Colors.white),
            ),
            SizedBox(height: 8),
            Text(title.toUpperCase(), style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Logout'),
          content: Text('Are you sure you want to logout?'),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Logout'),
              onPressed: () {
                Navigator.of(context).pop();
                _logout();
              },
            ),
          ],
        );
      },
    );
  }

  void _logout() {
    // Clear user session data if needed
    // For example, you might clear SharedPreferences here

    // Navigate to login screen
    Navigator.pushReplacementNamed(context, '/login');
  }
}

void main() {
  runApp(MaterialApp(
    home: SuperAdminDashboard(),
    routes: {
      '/overview': (context) => OverviewPage(),
      '/manage_users': (context) => ManageUsersPage(),
      '/reports': (context) => ReportsPage(),
      '/settings': (context) => SettingsPage(),
      //'/login': (context) => LoginPage(),
    },
  ));
}
